<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::select("TRUNCATE TABLE  products");

        \DB::table('products')->insert(array(
            array(
               'product_name' => 'magazines',
               'price' => '50',
               'created_at' => date('Y-m-d H:i:s'),
               'updated_at' => date('Y-m-d H:i:s'),
             ),
             array(
               'product_name' => 'Snacks',
               'price' => '100',
               'created_at' => date('Y-m-d H:i:s'),
               'updated_at' => date('Y-m-d H:i:s'),
             ),
             array(
               'product_name' => 'Tissues',
               'price' => '70',
               'created_at' => date('Y-m-d H:i:s'),
               'updated_at' => date('Y-m-d H:i:s'),
             ),
             array(
               'product_name' => 'Soap',
               'price' => '20',
               'created_at' => date('Y-m-d H:i:s'),
               'updated_at' => date('Y-m-d H:i:s'),
             ),
             array(
               'product_name' => 'Drinks',
               'price' => '75',
               'created_at' => date('Y-m-d H:i:s'),
               'updated_at' => date('Y-m-d H:i:s'),
             ),
       ));
    }
}
