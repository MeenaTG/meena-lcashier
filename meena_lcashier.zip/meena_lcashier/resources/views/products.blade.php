<div class="container">
    <h3>Welcome {!! \Auth::user()->name !!},</h3>
    <h2 style="margin-left: 40px;">Products</h2>
    <div class="grid">
        <div class="content">
            <ul class="rig columns-4">
                @if(count($aProducts) > 0)
                  @foreach($aProducts as $key => $value)
                    <li>
                        <h4>{!! $value->product_name !!}</h4>
                        <div class="price">{!! $currency_symbol.' '.$value->price !!}</div>
                        <a href="{!! \URL::to('purchase/'.$value->id) !!}">
                          <button class="btn btn-default btn-xs pull-right" type="button" style="cursor: pointer;">
                              <i class="fa fa-cart-arrow-down"></i> Buy now
                          </button>
                        </a>
                    </li>
                  @endforeach
                @else
                  <li>
                    <h4>Products haven't created yet</h4>
                    <div class="price">To create products , run seeder command in terminal</div>
                  </li>
                @endif
            </ul>
        </div>
    </div>
    <div>
      @if($purchase_count > 0)
      <a  href="{!! route('purchase-history') !!}">View Purchase</a>
      <br>
      @endif
      <a  href="{!! route('logout') !!}">Logout</a>
    </div>
    </div>
</div>
<style type="text/css">
  @import url(//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css);
  *,
  *:before,
  *:after {box-sizing: border-box;}
  .grid { display: grid; grid-auto-columns: 1fr 200px; }
  .content { grid-column: 1; }
  .grid > * { border: 0px;  }
  body { background: #fff; }
  ul.rig { list-style: none; font-size: 0px; margin-left: -2.5%; }
  ul.rig li { display: inline-block; padding: 10px; margin: 0 0 2.5% 2.5%; background: #fff; border: 1px solid #ddd; font-size: 16px; font-size: 1rem; vertical-align: top; box-shadow: 0 0 0px #000000; box-sizing: border-box; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; }
  ul.rig li img { max-width: 80%; height: auto; margin: 0 0 10px; }
  ul.rig li h3 { margin: 0 0 10px; }
  ul.rig li p { font-size: 1.0em; line-height: 1.5em; color: #000000; }
  ul.rig.columns-2 li { width: 47.5%; }
  ul.rig.columns-3 li { width: 30.83%; }
  ul.rig.columns-4 li { width: 22.5%; }
  @media (max-width: 680px) {
    ul.grid-nav li { display: inline-block; margin: 0 0 5px;
    }
    ul.grid-nav li a { display: inline-block; margin: 0 0 5px; }
    ul.rig { margin-left: 0; }
    ul.rig li { width: 100% !important; margin: 0 0 10px; } 
}
</style>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>