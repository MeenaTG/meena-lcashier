<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<div class="container">
    <div class="page-header">
        <h1>Product Purchase </h1>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 body-main">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-4"> <img class="img" alt="Invoce Template" src="{!! url('asset/img/cart.png') !!}"> </div>
                        <div class="col-md-8 text-right">
                            <h4 style="color: #F81D2D;"><strong>Shop</strong></h4>
                            <p>xxx Street</p>
                            <p>456789123</p>
                            <p>example@app.com</p>
                            <p>{!! date('d M Y') !!}</p>
                        </div>
                    </div> <br />
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h2>Bill Detail</h2>
                        </div>
                    </div> <br />
                    <div style="margin-bottom: 50px;">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>
                                        <h5>Description</h5>
                                    </th>
                                    <th>
                                        <h5>Amount</h5>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="col-md-9">{!! $aProduct->product_name !!}</td>
                                    <td class="col-md-3"> {!! $currency_symbol.' '.$aProduct->price !!} </td>
                                </tr>
                            </tbody>
                        </table>
                        <label for="card-holder-name">Card Holder Name</label>
                        <input id="card-holder-name" type="text" value="{!! \Auth::user()->name !!}">
                        <div id="card-element" style="margin-bottom: 10px;"></div>
                        <button id="card-button" class="btn btn-success" style="margin-bottom: 10px;" data-secret="{{ $intent->client_secret }}">
                            Pay
                        </button>
                        <div class="alert alert-success" style="display: none;">success message</div>
                        <div class="alert alert-danger" style="display: none;">error message</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<form action="{!! \URL::to('payhandler') !!}" method="post" id="payh-form">
    @csrf
    <input type="hidden" name="product_id" value="{!! $aProduct->id !!}">
    <input type="hidden" name="pay_id" id="pay_id" value="">
    <input type="hidden" name="pay_method" id="pay_method" value="">
</form>
<script src="https://js.stripe.com/v3/"></script>
<script>
    const skey = "{!! env('STRIPE_KEY') !!}";
    const stripe = Stripe(skey);

    const elements = stripe.elements();
    const cardElement = elements.create('card');

    cardElement.mount('#card-element');

    const cardHolderName = document.getElementById('card-holder-name');
    const cardButton = document.getElementById('card-button');
    const clientSecret = cardButton.dataset.secret;

    cardButton.addEventListener('click', async (e) => {
        $("#card-button").prop('disabed',true);
        const { setupIntent, error } = await stripe.confirmCardSetup(
            clientSecret, {
                payment_method: {
                    card: cardElement,
                    billing_details: { name: cardHolderName.value }
                }
            }
        );

        if (error) {
            $("#card-button").prop('disabed',false);
            $(".alert-danger").text(error.message);
            $(".alert-danger").show();
        } else {
            $(".alert-danger").hide();
            $("#pay_id").val(setupIntent.id);
            $("#pay_method").val(setupIntent.payment_method);
            console.log(setupIntent);
            $("#payh-form").submit();
        }
    });
</script>
<style type="text/css">
    .body-main { background: #ffffff; border-bottom: 15px solid #1E1F23; border-top: 15px solid #1E1F23; margin-top: 30px; margin-bottom: 30px; padding: 40px 30px !important; position: relative; box-shadow: 0 1px 21px #808080; font-size: 10px }
    .main thead { background: #1E1F23; color: #fff }
    .img { height: 100px }
    h1 { text-align: center }
    #card-holder-name { width: 100%; height: 30px; margin-bottom: 10px; }
</style>