<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<style type="text/css">
	body{ padding-top:4.2rem; padding-bottom:4.2rem; background:rgba(0, 0, 0, 0.76); }
	a{ text-decoration:none !important; }
	h1,h2,h3{ font-family: 'Kaushan Script', cursive; }
	.myform{ position: relative; display: -ms-flexbox; display: flex; padding: 1rem; -ms-flex-direction: column; flex-direction: column; width: 100%; pointer-events: auto; background-color: #fff; background-clip: padding-box; border: 1px solid rgba(0,0,0,.2); border-radius: 1.1rem; outline: 0; max-width: 500px; }
	.tx-tfm{ text-transform:uppercase; }
	.mybtn{ border-radius:50px; }
	form .error { color: #ff0000; }
</style>
<body>

    <div class="container">
        <div class="row">
            <div class="col-md-5 mx-auto">
                    <div class="myform form ">
                    	<?php if($errors->any()): ?>
						    <p class="alert alert-danger">The following errors occurred</p>
						<?php endif; ?>
						<?php if(Session::has('message')): ?>
							<p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
						<?php endif; ?>
                        <div class="logo mb-3">
                            <div class="col-md-12 text-center">
                                <h1 >Signup</h1>
                            </div>
                        </div>
                        <form method="post" action="<?php echo e(route('register')); ?>">
  							<?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Username</label>
                                <input type="text"  name="name" class="form-control" id="firstname" aria-describedby="emailHelp" placeholder="Enter Firstname" value="<?php echo e(old('name')); ?>">
                                <?php if($errors->has('name')): ?>
								    <div class="error"><?php echo e($errors->first('name')); ?></div>
								<?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email address</label>
                                <input type="email" name="email"  class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" value="<?php echo e(old('email')); ?>">
                                <?php if($errors->has('email')): ?>
								    <div class="error"><?php echo e($errors->first('email')); ?></div>
								<?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Password</label>
                                <input type="password" name="password" id="password"  class="form-control" aria-describedby="emailHelp" placeholder="Enter Password">
                                <?php if($errors->has('password')): ?>
								    <div class="error"><?php echo e($errors->first('password')); ?></div>
								<?php endif; ?>
                            </div>
                            <div class="col-md-12 text-center mb-3">
                              <button type="submit" class=" btn btn-block mybtn btn-primary tx-tfm">Submit</button>
                           </div>
                            <div class="col-md-12 ">
                                <div class="form-group">
                                    <p class="text-center"><a href="<?php echo e(route('login')); ?>" id="signin">Already have an account?</a></p>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div> 
    </body>
</body><?php /**PATH /var/www/html/test/example-app/resources/views/register.blade.php ENDPATH**/ ?>