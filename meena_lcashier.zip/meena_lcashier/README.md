
Installation procedure : 

1. Downoad and save the package in your local server.
2. Change database configuration in .env file which is located in root folder
3. Create the database as per your database config
4. Open termina and go to project directory
5. Run this command to import tables ----- "php artisan migrate"
6. To insert products run this command "php artisan db:seed" ----- installation competed
7. Now run the project in browser and register new account
8. After logging in, you can view the prodcuts.
9. Before purchase, store your stripe configuration in .env file

Thanks