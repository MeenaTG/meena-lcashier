<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Purchase extends Model
{
    use HasFactory;

    function getProductNameAttribute()
    {
    	$product = Products::find($this->product_id);
    	$name = !empty($product) ? $product->product_name : '';
    	return $name;
    }

    function getDateTextAttribute()
    {
    	return date('d M Y, g:i A',strtotime($this->created_at));
    }
}
