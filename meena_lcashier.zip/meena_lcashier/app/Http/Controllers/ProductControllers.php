<?php
namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Products;
use Laravel\Cashier\Cashier;
use App\Models\Purchase;

class ProductControllers extends Controller
{  
    function __construct()
    {
    	$this->currency_symbol = 'Rs ';
    }

    function products()
    {
        $aProducts = Products::get();
        $user = User::find(\Auth::id());
        $stripe_id = \Auth::user()->stripe_id;
        if(is_null($stripe_id) || $stripe_id == ''){
			$stripeCustomer = $user->createAsStripeCustomer();
        }
        $currency_symbol = $this->currency_symbol;
        $purchase_count = count($user->purchase);
    	return view('products',compact('aProducts','currency_symbol','purchase_count'));
    }

    function purchase_products(Request $request)
    {
    	$aProduct = Products::find($request->id);
    	if(!empty($aProduct)){
    		$user = User::find(\Auth::id());
    		$intent = $user->createSetupIntent();
    		$currency_symbol = $this->currency_symbol;
    		return view('purchase',compact('intent','aProduct','currency_symbol'));
    	}
    	session()->flash('error-message', 'Invalid product');
        return redirect()->back();
    }

    function payhandler(Request $request)
    {
        $user = User::find(\Auth::id());
        $aProduct = Products::find($request->product_id);
        $price = (int) ($aProduct->price*100);
        $rprice = (int) $aProduct->price;
        $user->addPaymentMethod($request->pay_method);
        try {
            $stripeCharge = $user->charge(
                $price, $request->pay_method
            );
        } catch (Exception $e) {
            session()->flash('error-message', 'Invalid product');
            return redirect()->back();
        }
        $purchase = new Purchase;
        $purchase->user_id = $user->id;
        $purchase->product_id = $aProduct->id;
        $purchase->price = $rprice;
        $purchase->payment_id = $stripeCharge->id;
        $purchase->status = $stripeCharge->status;
        $purchase->created_at = date('Y-m-d H:i:s');
        $purchase->updated_at = date('Y-m-d H:i:s');
        $purchase->save();
        return redirect()->to('purchase-history');
    }

    function purchase_history()
    {
        $user = User::find(\Auth::id());
        $aPurchase = Purchase::where('user_id',$user->id)->orderBy('id','desc')->paginate(10);
        $currency_symbol = $this->currency_symbol;
        return view('purchase-history',compact('aPurchase','currency_symbol'));
    }
}
?>