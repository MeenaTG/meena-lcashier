<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/billing-portal', function (Request $request) {
    return $request->user()->redirectToBillingPortal();
});
Route::namespace('App\Http\Controllers\Auth')->group(function () {
  Route::get('/','LoginController@home');
  Route::get('/login','LoginController@show_login_form')->name('login');
  Route::post('/login','LoginController@process_login')->name('login');
  Route::get('/register','LoginController@show_signup_form')->name('register');
  Route::post('/register','LoginController@process_signup');
  Route::get('/logout','LoginController@logout')->name('logout');
});

Route::get('home','App\Http\Controllers\ProductControllers@products')->name('home')->middleware('auth');
Route::get('products','App\Http\Controllers\ProductControllers@products')->name('products')->middleware('auth');
Route::get('purchase/{id}','App\Http\Controllers\ProductControllers@purchase_products')->name('purchase_products')->middleware('auth');
Route::post('payhandler','App\Http\Controllers\ProductControllers@payhandler')->name('payhandler')->middleware('auth');
Route::get('purchase-history','App\Http\Controllers\ProductControllers@purchase_history')->name('purchase-history')->middleware('auth');